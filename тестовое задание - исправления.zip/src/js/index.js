import "../style/main.scss";
import '../js/main';